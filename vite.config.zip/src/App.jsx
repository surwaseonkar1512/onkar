
import reactLogo from './assets/react.svg'
import './App.css'


import Home from './components/Home'
import Port from './components/Port'
import Port2 from './components/Port2'
import Skill from './components/Skill'
import Footer from './components/Footer'

function App() {


  return (
    <div >
    <Home/>
 
    <Skill/>
  
    <Port2/>
    <Footer/>
    </div>
  )
}

export default App
