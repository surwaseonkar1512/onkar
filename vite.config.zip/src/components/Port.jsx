import React from 'react'
import p4 from "../assets/p4.png"
import p5 from "../assets/p5.png"
import p1 from "../assets/p1.jpg"
import p2 from "../assets/p2.jpg"
import git from "../assets/git.png"
const Port = () => {
  return (
    <div id='portfolio' className='bg-Pbg font-Poppins  h-screen bg-no-repeat w-full  bg-cover   '>
        <div id="works"  class="  w-[90%]justify-center flex items-center pl-8 sm:w-[90%]">
      <div class="container mx-auto w-[90%] sm:w-[90%]">
       
        <div class="flex flex-col gap-3 pt-1 items-center">
          <h1 class="text-indigo-600 font-Poppins font-bold text-3xl">PORTFOLIO</h1>
          <h1 class="text-3x text-white">Works & Projects</h1>
          
        </div>
       
        <div class="p-5 sm:p-0 flex flex-wrap justify-between">
         
         
        <div
            class="w-full    md:w-5/12 lg:w-[40%] shadow-xl rounded-lg  my-3 md:my-10  m-1 transition-all hover:scale-110  group hover:bg-gradient-to-r from-gray-200 to-red-500
             sm:hover:[hover:scale-100]"
          >
            <img src={p1} alt="/" className='rounded-xl cursor-pointer group-hover:opacity-10' />
            <div className=' hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold text-white tracking-wider text-center flex-auto '>
                 HighKing
            </h3>
              <a href='https://github.com/surwaseonkar1512/highking.reaactjs' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='https://highkingwithsurya.netlify.app/' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
         
          <div
            class="w-full   md:w-5/12 lg:w-[40%] shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110  group hover:bg-gradient-to-r from-gray-200 to-red-500
             sm:hover:[hover:scale-159]"
          >
            <img src={p2} alt="/" className='rounded-xl cursor-pointer group-hover:opacity-10' />
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
                 Youtube-Clone
            </h3>
              <a href='https://github.com/surwaseonkar1512/YoutubeApp.react' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='https://suryamediain.netlify.app/' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           </div>

          </div>

          <div
            class="w-full  md:w-5/12 lg:w-[40%] shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110  group hover:bg-gradient-to-r from-gray-200 to-red-500
             sm:hover:[hover:scale-159]"
          >
            <img src={p5} alt="/" className='rounded-xl cursor-pointer group-hover:opacity-10' />
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
                 Netflix-clone
            </h3>
              <a href='https://github.com/surwaseonkar1512/netflix-clone' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='https://netflix-surya1.netlify.app/' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
       

          <div
            class="w-full   md:w-5/12 lg:w-[40%] shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110  group hover:bg-gradient-to-r from-gray-200 to-red-500
             sm:hover:[hover:scale-159]"
          >
            <img src={p4} alt="/" className='rounded-xl cursor-pointer group-hover:opacity-10' />
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
                 Photographer PortFolio
            </h3>
              <a href='https://github.com/surwaseonkar1512/highking.reaactjs' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='http://amarpatil.netlify.app' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
            
        {/**
             <div
            class="w-full md:w-5/12 lg:w-1/5 shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110  group hover:bg-gradient-to-r from-gray-200 to-red-500
             sm:hover:[hover:scale-159]"
          >
            <img src={p1} alt="/" className='rounded-xl cursor-pointer group-hover:opacity-10' />
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
                 HighKing
            </h3>
              <a href='https://github.com/surwaseonkar1512/highking.reaactjs' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='https://highkingwithsurya.netlify.app/' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
        
         */}
        </div>
        </div>
        </div>

    </div>
   
  )
}

export default Port