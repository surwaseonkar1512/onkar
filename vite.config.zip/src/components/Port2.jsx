import React from 'react'
import pp3 from "../assets/pp3.jpeg"
import pn2 from "../assets/pn2.jpeg"
import p1 from "../assets/p1.jpg"
import py1 from "../assets/py1.jpeg"
import git from "../assets/git.png"
const Port2 = () => {
  return (
    <div id="works" className="font-Poppins  w-full h-auto bg-gradient-to-r from-teal-500 py-40 dark:bg-slate-900">
      <div className="container mx-auto">
    
        <div className=" font-Poppins flex flex-col gap-3 items-center">
          <h1 className="text-indigo-600 font-bold">PORTFOLIO</h1>
          <h1 className="text-3xl dark:text-white">Works & Projects</h1>
          <p className="w-1/2 text-center text-gray-400">
            
          </p>
        </div>
      
        <div className="p-5 sm:p-0 flex flex-wrap justify-between font-Poppins ">
          
       <div
            className="w-full md:w-5/12 lg:w-2/5  shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110
             group hover:bg-gradient-to-r from-gray-200 to-red-500 sm:hover:[hover:scale-100] ">
         
            <img  src={p1} alt='/' className='rounded-xl cursor-pointer group-hover:opacity-10'/>
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-xl font-bold texxt-white tracking-wider text-center flex-auto '>
             HighKing
            </h3>
              <a href='https://github.com/surwaseonkar1512/highking.reaactjs' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='https://highkingwithsurya.netlify.app/' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
          
          <div
            className="w-full md:w-5/12 lg:w-2/5  shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110
             group hover:bg-gradient-to-r from-gray-200 to-red-500 sm:hover:[hover:scale-100]"
          >
            <img  src={py1} alt='/' className='rounded-xl cursor-pointer group-hover:opacity-10'/>
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
                Youtube-clone
            </h3>
              <a href='https://github.com/surwaseonkar1512/YoutubeApp.react' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='https://suryamediain.netlify.app/' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
          
          <div
            className="w-full md:w-5/12 lg:w-2/5  shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110
             group hover:bg-gradient-to-r from-gray-200 to-red-500 sm:hover:[hover:scale-100]"
          >
            <img  src={pn2} alt='/' className='rounded-xl cursor-pointer group-hover:opacity-10'/>
            <div className='  hidden group-hover:block w-[50%] h-auto absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
               Netflix-clone
            </h3>
              <a href='https://github.com/surwaseonkar1512/netflix-clone' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='https://netflix-surya1.netlify.app/' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
          
          <div
            className="w-full md:w-5/12 lg:w-2/5  shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110
             group hover:bg-gradient-to-r from-gray-200 to-red-500 sm:hover:[hover:scale-100]"
          >
            <img  src={pp3} alt='/' className='rounded-xl cursor-pointer group-hover:opacity-10'/>
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
                Photographer portfolio
            </h3>
              <a href='https://github.com/surwaseonkar1512/highking.reaactjs' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='http://amarpatil.netlify.app' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
          <div
            className="w-full md:w-5/12 lg:w-2/5  shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110
             group hover:bg-gradient-to-r from-gray-200 to-red-500 sm:hover:[hover:scale-100]"
          >
            <img  src={pp3} alt='/' className='rounded-xl cursor-pointer group-hover:opacity-10'/>
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
                Photographer portfolio
            </h3>
              <a href='https://github.com/surwaseonkar1512/highking.reaactjs' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='http://amarpatil.netlify.app' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
          <div
            className="w-full md:w-5/12 lg:w-2/5  shadow-xl rounded-lg my-3 md:my-10 m-1 transition-all hover:scale-110
             group hover:bg-gradient-to-r from-gray-200 to-red-500 sm:hover:[hover:scale-100]"
          >
            <img  src={pp3} alt='/' className='rounded-xl cursor-pointer group-hover:opacity-10'/>
            <div className='  hidden group-hover:block absolute top-[50%] left-[50%] translate-x-[-50%] translate-y-[-50%]'>
              <h3 className='text-2xl font-bold texxt-white tracking-wider text-center flex-auto '>
                Photographer portfolio
            </h3>
              <a href='https://github.com/surwaseonkar1512/highking.reaactjs' className=' flex-autobtn text-bold w-[25%]'>
                <img src={git} alt='/' className='w-[50%]'/>
               </a>
               <a href='http://amarpatil.netlify.app' >
               <button  className="text-2xl font-medium   border-black p-2 rounded-xl  bg-blue-500">
              Live Demo
            </button>
               </a>
           
            </div>
          </div>
          
        
          
          
          
       
          
        
        </div>
      </div>
    </div>
  )
}

export default Port2