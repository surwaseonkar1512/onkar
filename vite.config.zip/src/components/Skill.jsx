import React from 'react'
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/autoplay";
import s1 from "../assets/s1.png";
import s2 from "../assets/s2.png";
import s3 from "../assets/s3.png";
import s4 from "../assets/s4.png";
import s5 from "../assets/s5.png";
import s6 from "../assets/s6.png";
import s7 from "../assets/s7.png";
import s8 from "../assets/s8.png";
import { Autoplay, Pagination } from "swiper";
const Skill = () => {
  return (
     <div id='skills' className='bg-gradient-to-r from-indigo-500 font-Poppins  bg-center h-2/4 bg-no-repeat w-full bg-cover bg-opacity-90  '>
       <div className=' text-dark text-5xl justify-center flex flex-row items-center pt-14  m-2 gap-3'>
       <span className='font-Poppins text-black'>
        Skills </span> 
        and 
        <span className='text-black'> Tools </span> 
       </div>

      <section className="text-center pt-15   bg-cover bg-fixed pb-24 ">
      <div className="my-6">
        <Swiper
          loop={true}
          grabCursor={true}
          spaceBetween={30}
          centeredSlides={true}
          pagination={{
            clickable: true,
          }}
          modules={[Pagination,Autoplay]}
          
            autoplay={ {delay:1000} }

          breakpoints={{
            1024: {
              slidesPerView: 3,
            },
            600: {
              slidesPerView: 2,
            },
            400: {
              slidesPerView: 1,
            },
          }}
          className="mySwiper pt-20 px-4 py-20"
        >
          <SwiperSlide modules={[Autoplay]}
             autoplay={ {delay:1000} }>
            <div
              className="flex flex-col justify-center shadow-2xl rounded-lg
             p-8"
         
            > <img src={s4} alt="avatar" className="w-[40%] h-[40%] mx-auto " />
           
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src={s1} alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src={s2} alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src={s3} alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src='https://www.vectorlogo.zone/logos/tailwindcss/tailwindcss-icon.svg' alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src={s4} alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src={s5} alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src={s6} alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src={s7} alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
          <SwiperSlide>
            <div className="flex flex-col justify-center shadow-2xl rounded-lg p-8">
              <img src={s8} alt="avatar" className="w-[40%] h-[40%] mx-auto" />
             
            </div>
          </SwiperSlide>
        </Swiper>
      </div>
    </section>



    </div>
  )
}

export default Skill