import React from 'react'
import Typewriter from 'typewriter-effect';
import onkar from '../assets/onkar1.png'
import Home2 from './Home2';
import bgv from '../assets/bgv.mp4'

const Home = () => {
  return (
    <div className='bg-gradient-to-r from-indigo-500 '>
       <div className='w-[100%] h-screen'>
    <div className='absolute  w-[100%] h-[100%] '>
    <video className='w-full h-screen object-cover opacity-70 ' autoPlay muted loop src={bgv}/>
    <div className=' w-[100%] h-[100%] top-[50%] left-[-10%]  flex flex-col items-center  text-5xl text-black '>
          <Home2/>
    </div>
    </div>
    </div>
 
    </div>
  )
}

export default Home

{
  /** <section className="min-h-screen  " >
 
 <div className="text-start pt-[1rem] ">
 <div className=' flex flex-col '>

   <div className="text-start text-3xl py-2 text-black font-medium md:text-6xl pt-[230px]">
         Onkar Surwase
         <h3 className="text-start text-2xl text-black py-2 md:text-6xl">
       <Typewriter
        
        options={{
          strings: ['Frontend devloper', 'UI designer'],
          autoStart: true,
          loop: true,
          
        }}
      />
    </h3>
   </div>
 
   <img className='m-0 ' src={onkar} alt=''/>

  
 </div>

     
 </div>
</section> */
}