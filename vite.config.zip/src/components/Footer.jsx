import React from 'react'
import { BsGithub,BsInstagram } from 'react-icons/bs';
import {AiFillLinkedin } from 'react-icons/ai';
const Footer = () => {
  return (
    <footer className="font-Poppins  text-center flex flex-row items-center justify-center bg-gray-900 text-white">
    <div className="container px-6 pt-6">
    <div className="  text-5xl flex items-center justify-center gap-16 py-3 text-gray-600 dark:text-gray-400">
                   <a href='https://github.com/surwaseonkar1512'>   <BsGithub   /></a>
                   <a href='https://www.linkedin.com/in/onkar-surwase-7b357124a/'><AiFillLinkedin/></a>
                   <a href='https://www.instagram.com/surwase.onkar/'><BsInstagram/></a>
           
            </div>
  
    <div className="font-Poppins  text-center p-4" >
      © 2023 Copyright :
      <a className="text-white" href="https://www.instagram.com/surwase.onkar/"> Onkar Surwase</a>
    </div>
    </div>
  </footer>
  )
}

export default Footer